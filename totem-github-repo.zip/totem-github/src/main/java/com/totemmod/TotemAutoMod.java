package com.totemmod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.entity.effect.StatusEffects;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TotemAutoMod implements ModInitializer {

    public static final String MOD_ID = "totem-auto-mod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    // 3 hearts = 6 HP — low health trigger
    private static final float TRIGGER_HEALTH = 6.0f;
    // 7 hearts = 14 HP — stop equipping totems after recovery
    private static final float TARGET_HEALTH = 14.0f;

    private int swapCooldown = 0;

    @Override
    public void onInitialize() {
        LOGGER.info("[TotemAutoMod] Loaded!");

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.world == null) return;

            PlayerEntity player = client.player;

            if (swapCooldown > 0) {
                swapCooldown--;
                return;
            }

            float health = player.getHealth();

            // ── Trigger 1: health already below 3 hearts ──────────────────
            if (health < TRIGGER_HEALTH) {
                equipTotemInOffhand(client, player);
                swapCooldown = 2;
                return;
            }

            // ── Trigger 2: fall damage prediction ─────────────────────────
            // fallDistance is how many blocks the player has fallen so far.
            // Minecraft deals fall damage for every block beyond 3 (safe fall height).
            // Formula: damage = fallDistance - 3 (reduced by Jump Boost if active)
            // Each damage point = 1 HP (0.5 hearts).
            float fallDist = player.fallDistance;

            if (fallDist > 3f) {
                float predictedDamage = calculateFallDamage(player, fallDist);

                // If the predicted fall damage would bring health to 0 or below, equip totem
                if (health - predictedDamage <= 0) {
                    LOGGER.info("[TotemAutoMod] Lethal fall detected! Dist: {:.1f}, Dmg: {:.1f}, HP: {}",
                            fallDist, predictedDamage, health);
                    equipTotemInOffhand(client, player);
                    swapCooldown = 2;
                }
            }
        });
    }

    /**
     * Calculate expected fall damage.
     * Minecraft formula: damage = fallDistance - 3
     * Jump Boost reduces safe fall height by 1 per level.
     * Feather Falling and armor reduce damage but we calculate raw damage here
     * to be safe — better to equip totem unnecessarily than miss it.
     */
    private float calculateFallDamage(PlayerEntity player, float fallDistance) {
        // Base safe fall height is 3 blocks
        float safeFall = 3f;

        // Jump Boost increases safe fall height by 1 per level
        if (player.hasStatusEffect(StatusEffects.JUMP_BOOST)) {
            int level = player.getStatusEffect(StatusEffects.JUMP_BOOST).getAmplifier() + 1;
            safeFall += level;
        }

        float damage = fallDistance - safeFall;
        return Math.max(0f, damage);
    }

    private void equipTotemInOffhand(MinecraftClient client, PlayerEntity player) {
        ItemStack offhand = player.getOffHandStack();
        if (offhand.isOf(Items.TOTEM_OF_UNDYING)) return;

        int totemSlot = findTotemInInventory(player);
        if (totemSlot == -1) return;
        if (client.interactionManager == null) return;

        int screenSlot = inventoryIndexToScreenSlot(totemSlot);

        // Pick up totem
        client.interactionManager.clickSlot(
                player.playerScreenHandler.syncId,
                screenSlot, 0, SlotActionType.PICKUP, player);

        // Place in offhand (slot 40)
        client.interactionManager.clickSlot(
                player.playerScreenHandler.syncId,
                40, 0, SlotActionType.PICKUP, player);

        // If something was in offhand, put it back
        ItemStack cursor = player.playerScreenHandler.getCursorStack();
        if (!cursor.isEmpty()) {
            client.interactionManager.clickSlot(
                    player.playerScreenHandler.syncId,
                    screenSlot, 0, SlotActionType.PICKUP, player);
        }

        LOGGER.info("[TotemAutoMod] Totem equipped from slot {}. HP: {}", totemSlot, player.getHealth());
    }

    private int findTotemInInventory(PlayerEntity player) {
        for (int i = 0; i < 9; i++) {
            if (player.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) return i;
        }
        for (int i = 9; i < 36; i++) {
            if (player.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) return i;
        }
        return -1;
    }

    private int inventoryIndexToScreenSlot(int inventoryIndex) {
        return inventoryIndex < 9 ? 36 + inventoryIndex : inventoryIndex;
    }
}
